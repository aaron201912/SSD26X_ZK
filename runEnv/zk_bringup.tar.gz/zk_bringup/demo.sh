mkdir /var/tmp

/customer/browser/run.sh &
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/lib:/customer/lib:/customer/libsecurity:/customer/libdns:/lib:/config/lib:/config/wifi
echo 12 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio12/direction
echo 1 > /sys/class/gpio/gpio12/value
echo 13 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio13/direction
echo 1 > /sys/class/gpio/gpio13/value
echo 135 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio135/direction
echo 1 > /sys/class/gpio/gpio135/value
cd /customer
chmod 777 zkgui
./zkgui &
