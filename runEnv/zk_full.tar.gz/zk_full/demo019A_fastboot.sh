mkdir /var/tmp

#/customer/browser/run.sh &
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/lib:/customer/lib:/customer/libsecurity:/customer/libdns:/lib:/config/lib:/config/wifi
cd /customer
chmod 777 MyPlayer
chmod 777 zkgui
./zkgui &
