mkdir /var/tmp

#/customer/browser/run.sh &
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/lib:/customer/lib:/customer/libsecurity:/customer/libdns:/lib:/config/lib:/config/wifi
echo 130 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio130/direction
echo 1 > /sys/class/gpio/gpio130/value
echo 136 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio136/direction
echo 1 > /sys/class/gpio/gpio136/value
echo 138 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio138/direction
echo 1 > /sys/class/gpio/gpio138/value
cd /customer
chmod 777 MyPlayer
chmod 777 zkgui
./zkgui &
